{{/*
Create a unique name for a cluster-scoped resource.
*/}}
{{- define "qualys-tc.clusterResourceName" -}}
{{- printf "%s-%s-%s" .Release.Name .Release.Namespace .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Whether customer credentials should be sourced from a Kubernetes Secret.
Returns "true" when enabled (create=true or an existing name is set), empty otherwise.
*/}}
{{- define "qualys-tc.credentialsSecretEnabled" -}}
{{- $secret := (.Values.global | default dict).credentialsSecret | default dict -}}
{{- if or $secret.create $secret.name -}}
true
{{- end -}}
{{- end -}}

{{/*
Name of the Kubernetes Secret holding CUSTOMER_ID and ACTIVATION_ID.
When create=true, defaults to "qualys-credentials" unless an explicit name is provided.
When create=false, an explicit name is required.
*/}}
{{- define "qualys-tc.credentialsSecretName" -}}
{{- $secret := (.Values.global | default dict).credentialsSecret | default dict -}}
{{- if $secret.create -}}
{{- default "qualys-credentials" $secret.name -}}
{{- else -}}
{{- $secret.name | required ".Values.global.credentialsSecret.name is required when credentialsSecret.create is false." -}}
{{- end -}}
{{- end -}}

{{/*
Validate that a user-supplied credentials Secret exists in the cluster and
contains the required CUSTOMER_ID / ACTIVATION_ID keys.
Uses Helm lookup, so it only works during install/upgrade against a cluster.
*/}}
{{- define "qualys-tc.validate.credentialsSecret" -}}
{{- $global := .Values.global | default dict -}}
{{- $secret := $global.credentialsSecret | default dict -}}
{{- if and (not $secret.create) $secret.name -}}
  {{- $existingSecret := lookup "v1" "Secret" .Release.Namespace $secret.name -}}
  {{- if not $existingSecret -}}
    {{- fail (printf "invalid secret file for customer id: secret %s does not exist in namespace %s" $secret.name .Release.Namespace) -}}
  {{- end -}}
  {{- $customerId := index $existingSecret.data "CUSTOMER_ID" -}}
  {{- $activationId := index $existingSecret.data "ACTIVATION_ID" -}}
  {{- if not $customerId -}}
    {{- fail (printf "invalid secret file for customer id: secret %s is missing CUSTOMER_ID key" $secret.name) -}}
  {{- end -}}
  {{- if not $activationId -}}
    {{- fail (printf "invalid secret file for customer id: secret %s is missing ACTIVATION_ID key" $secret.name) -}}
  {{- end -}}
  {{- if eq $customerId "" -}}
    {{- fail (printf "invalid secret file for customer id: secret %s has empty CUSTOMER_ID key" $secret.name) -}}
  {{- end -}}
  {{- if eq $activationId "" -}}
    {{- fail (printf "invalid secret file for customer id: secret %s has empty ACTIVATION_ID key" $secret.name) -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Env entries that source CUSTOMER_ID and ACTIVATION_ID from the credentials Secret.
Callers must guard with "qualys-tc.credentialsSecretEnabled".
*/}}
{{- define "qualys-tc.credentialsSecretEnv" -}}
- name: CUSTOMER_ID
  valueFrom:
    secretKeyRef:
      name: {{ include "qualys-tc.credentialsSecretName" . }}
      key: CUSTOMER_ID
- name: ACTIVATION_ID
  valueFrom:
    secretKeyRef:
      name: {{ include "qualys-tc.credentialsSecretName" . }}
      key: ACTIVATION_ID
{{- end -}}
