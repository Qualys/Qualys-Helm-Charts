# Qualys Harbor Adapter Service

[Qualys Harbor Adapter Service](https://www.qualys.com/) It is a pluggable scanner service for Harbor registry where we can scan images pushed to registry also have scans scheduled for all the images.

The installation will deploy the Qualys Harbor Adapter Service on each worker node as a statefulset. By default, it assumes `containerd` as the default runtimes on `Kubernetes cluster`.

## Prerequisites

### Kubernetes & Helm

- Kubernetes 1.17+
- Helm v3.x.x

### Get Repository Info

- helm repo add adapter-svc-helm-chart
- helm repo update

## Installing the Chart

In values.yaml enter mandatory values from your environment as described in Configuration and keep this file in helmInstallationPath directory.

Note: All flagged Important are mandatory params

Note: values.yaml is being used for 3 purpose - Helm chart deployment, Service configuration (these changes are one time and if modified then pod restart would be required.), Scanner Flags (these flags are kept configurable and will get reflected for each scan job request without service restart)

Use the following command to install the chart:
`helm install [NAME] [CHART] [flags]`

- Install on Kubernetes cluster with containerd runtime (Default)
`helm install qualys-harbor-demo adapter-svc-helm-chart/qualys-harbor`
---
- Install on Kubernetes cluster with docker runtime
`helm install qualys-harbor-demo adapter-svc-helm-chart/qualys-harbor`
---

## Upgrading the Release

Use the following command to upgrade the chart:

`helm upgrade [RELEASE] [CHART] [flags]`

Where,

[RELEASE] is the release name.

[CHART] is the chart path.

e.g.

`helm upgrade qualys-harbor-demo adapter-svc-helm-chart/qualys-harbor`

## Uninstalling the Chart

Use the following command to uninstall the chart:

`helm uninstall RELEASE_NAME [...] [flags]`

e.g.

`helm uninstall qualys-harbor-demo`

## Persistent Cache requirement

With caching enabled we can increase scan job performance. [Note: first scan may take longer time but subsequent scans will be faster].
To support this we have enabled local as well as persistent cache.

cache-dir : location of cache mounted within pod.

local cache :- This cache will not be persisted incase of pods restart or redeployment. By default it is enabled and will be used as default location </opt/qualys/.cache/qualys/qscanner>. For other location can be set through cache-dir flag.

persistent cache :- This cache will be persisted accross redeployments or if pods restart. This will create persistent volume claim for all the replicas hence for this storage class should already be created with certain provisioning.
If storage class is manual then we need persistent volume created for every replica of scanner-pod.

```
Sample persistent volume yaml
{{- if .Values.persistence.enable }}
apiVersion: v1
kind: PersistentVolume
metadata:
  name: qscanner-cache0
  labels:
    type: local
spec:
  storageClassName: manual
  capacity:
    storage: {{ .Values.persistence.size }}
  accessModes: [ "ReadWriteMany" ]
  hostPath:
    path: {{ index .Values.scannerArgs "cache-dir" }}
{{- end }}
```
```
Sample storage class yaml
kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: manual
provisioner: kubernetes.io/no-provisioner
volumeBindingMode: WaitForFirstConsumer
```

## Configuration

#### Configurable Parameters

The following table lists the configurable parameters for the Qualys Harbor Adapter chart and their default values:
service restart required paramter is whether restart of service is required incase of value is modified. If Yes - restart is required else values modified will be picked up on runtime when new scan job is triggered.

Parameter | Description | Default | Notes | service restart required? |
--------- | ----------- | ------- | ----- | --------------------------|
`fullnameOverride` | This name will be used as service name which needs to be added under Interrogation Service as new Scanner.|`qualys-scanner` | **Important**: If TLS is enabled then certificate should have this name as dns. |'-'|
`helmInstallationPath` | The absolute path of values.yaml helm chart installtion. | `-` | **Important**: This is required as persistent volume would be mounted from this path within pod | Yes |
`persistence.enabled` | This is required to mount persistent cache within pod. | true | **Important**: This is required if persistent cache is required. |Yes|
`persistence.storageClass` | This is Storage class used for mounting persistent share. same is refered incase persistent cache is enabled | manual | **Important**: This is mandatory if persistent cache is required. If manual then persistent volumes should be created as per replicas on respective nodes |Yes|
`persistence.accessMode` | This is accessmode for persistent share same is refered incase persistent cache is enabled | ReadWriteMany | **Important**: This is mandatory if persistent cache is required. |Yes|
`persistence.size` | This is the disk size which will be allocated for persistent share.   | 3Gi | **Note** minimum required |Yes|
`redis.url` | Scanner service creates redis client connection to store job details which is refered on harbor UI. |  | **Important**: this has to be updated based on the environment. format: redis://harbor-redis:6379/ -> redis://<redis-svc-name:<port> default port is always 6379 in harbor environment |Yes|
`redis.maxActiveConnections` | This is maximum number of concurrent redis connections. This is configurable and if modified pod restart would be required. | 5 | **Note**: minimum no of connections |Yes|
`redis.maxIdleConnections` | This is maximum no of Idle connections without getting quickly closed port operation. | 5 | **Note**: minimum no of connections |Yes|
`service.workerThreads` | The number of workers to spin-up for the scan jobs queue | 2 | **Note**: minimum no of connections |Yes|
`service.scanJobTTLHour` | The time to live for persisting scan jobs and associated scan reports. | 1 |  |No|
`service.maxTimeout` | The maximum duration for all network requests [redis calls, api responses] | 1m |  |No|
`service.replicaCount` | This count is for how many instances of Qualys Harbor Scanner process will run serving job requests | 1 | **Note**: minimum no of connections |Yes|
`service.logLevel` | This is log level for Qualys Harbor Scanner Service | debug |  |Yes|
`service.port` | On this port Qualys Harbor Scanner Service will listen for incoming scan requests from Harbor. | 5000 |  |Yes|
`service.tlsEnabled` | This value is to spawn Qualys Harbor Scanner Service with TLS enabled | false | **Note**: This service runs in same cluster as other Harbor Services. |Yes|
`service.tlsCertData` | This is absolute path for TLS certificate file. |  |  |Yes|
`service.tlsKeyData` | This is absolute path for TLS key file. |  |  |Yes|
`service.disable-qualys-tls` | This is to mount tls certs for Qualys Backend if set to false. | true | |No|
`persistence.enable` | This is for enabling persistent local cache which will prevent loss of data even during pod crash/restart issue. | false | **Note**: With this option `scannerArgs.cache-dir` must be set to some local path which will get mounted. There might be certain performance degradation for first scan subsequent scans will get optimized. |Yes|
`scannerArgs.log-level` | This log-level is for each scan request job. | info |  |No|
`scannerArgs.cache` | This is for enabling local cache. If this is set to local and persistence.enable=false then local cache which wont be persisted incase of pod restart. | local | |No|
`scannerArgs.cache-dir` | If this is set then cache will be created on this location else default location will be used. | /root/.cache/qualys/qscanner |  |No|
`scannerArgs.pod` | Specify Qualys Platform (POD) for backend communication. For e.g: [US1 US2 US3 US4 EU1 EU2 EU3 IN1 CA1 AE1 UK1 AU1 KSA1].If your platform is not mentioned here, please provide the gateway URL using --gateway-url |  | **Important**: This is mandatory without this scan job will fail in fetching vulnerability report |No|
`scannerArgs.gateway-url` | Specify Qualys Platform (POD) gateway URL for backend communication. Please find the gateway URL for your POD at https://www.qualys.com/platform-identification. Alternatively, you can provide POD identifier via --pod flag |  | **Important**: This is mandatory without this scan job will fail in fetching vulnerability report |No|
`scannerArgs.access-token` | Specify Qualys access token to be used for backend communication |  | **Important**: This is getting **Deprecated** in next release. |No|
`scannerArgs.client-id` | Specify client id to be used for backend communication. Please contact Qualys Support to enable OAUTH for your subscription. |  | **Important**: This is mandatory without this scan job will fail in fetching vulnerability report. |No|
`scannerArgs.client-secret` | Specify client secret to be used for backend communication. Please contact Qualys Support to enable OAUTH for your subscription. |  | **Important**: This is mandatory without this scan job will fail in fetching vulnerability report. |No|
`scannerArgs.skip-verify-tls` | This is to skip TLS communication with Qualys Backend. | false | |No|
`scannerArgs.qualys-tags` | Specify values to be used for asset tagging. You can provide comma separated values. To enable continuous assessment on scanned assets, provide a value that has 'qca_scan' prefix. E.g: qca_scan_harbor_scanned_asset | "" | |No|
`scannerArgs.cert-path` | This is path for TLS certificate. Applicable only if skip-verify-tls=false. |  | |No|
`scannerArgs.proxy` | Specify proxy URL to use. If not it will use from env | '' | |No|
`scannerArgs.offline-scan` | This is to disable external API requests to identify dependencies. | false |  |No|
`scannerArgs.scan-timeout` | This is scan job maximum timeout  | 5m0s |  |No|
`scannerArgs.max-network-retries` | Set the max network retries value. After this amount of retries qscanner will not poll the backend | 10 |  |No|
`scannerArgs.network-retry-wait-min` | Time elapsed before Qualys Harbor Service sends the next poll request to Qualys backend. | 5s |  |No|
`scannerArgs.cache-cleanup-duration-threshold` | Qualys Harbor Service will cleanup cache after this threshold   | 4320h0m0s |  |No|
`scannerArgs.cache-cleanup-frequency` | This is the duration after which Qualys Harbor Service will attempt to perform cleanup of old unused local cache entries | 720h0m0s |  |No|
`scannerArgs.enable-cache-cleanup` | If true, Qualys Harbor Service will perform cleanup of old unused cache entries. | true |  |No|
`nodeSelector` | Set nodeSelector if the qualys harbor service needs to be deployed on specific node |  | | Yes | 
`affinity` | Set nodeAffinity, podAffnity and podAntiAffinity based on requirement |  |  | Yes | 
`tolerations` | Add toleration to schedule pod with matching taints  |  |  | Yes | 


---
## Contact
Contact <support@qualys.com> for assistance.
