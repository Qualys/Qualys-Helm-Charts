{{- define "qualys-scanner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "qualys-scanner.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "qualys-scanner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "qualys-scanner.labels" -}}
app.kubernetes.io/name: {{ include "qualys-scanner.name" . }}
helm.sh/chart: {{ include "qualys-scanner.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Credentials secret name (client id, client secret, access token).
*/}}
{{- define "qualys-scanner.credentialsSecretName" -}}
{{- if .Values.qualysPlatformAuth.existingSecret -}}
{{- .Values.qualysPlatformAuth.existingSecret -}}
{{- else -}}
{{- printf "%s-credentials" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Access token secret name.
*/}}
{{- define "qualys-scanner.accessTokenSecretName" -}}
{{- if .Values.qualysPlatformAuth.existingSecret -}}
{{- .Values.qualysPlatformAuth.existingSecret -}}
{{- else -}}
{{- printf "%s-access-token" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Qualys Platform authentication secret name.
*/}}
{{- define "qualys-scanner.authSecretName" -}}
{{- if .Values.qualysPlatformAuth.existingSecret -}}
{{- .Values.qualysPlatformAuth.existingSecret -}}
{{- else if index .Values.scannerArgs "access-token" -}}
{{- include "qualys-scanner.accessTokenSecretName" . -}}
{{- else -}}
{{- include "qualys-scanner.credentialsSecretName" . -}}
{{- end -}}
{{- end -}}

{{/*
Service TLS secret name.
*/}}
{{- define "qualys-scanner.serviceTlsSecretName" -}}
{{- if .Values.serviceTls.existingSecret -}}
{{- .Values.serviceTls.existingSecret -}}
{{- else -}}
{{- printf "%s-tls" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Qualys Platform CA certificate secret name.
*/}}
{{- define "qualys-scanner.qualysCaCertSecretName" -}}
{{- if .Values.qualysPlatformCaCert.existingSecret -}}
{{- .Values.qualysPlatformCaCert.existingSecret -}}
{{- else -}}
{{- printf "%s-qualys-platform-ca" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Registry CA certificate secret name.
*/}}
{{- define "qualys-scanner.registryCaCertSecretName" -}}
{{- if .Values.registryCaCert.existingSecret -}}
{{- .Values.registryCaCert.existingSecret -}}
{{- else -}}
{{- printf "%s-registry-ca" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Returns "true" when a registry CA certificate is configured.
*/}}
{{- define "qualys-scanner.registryCaCertConfigured" -}}
{{- if or .Values.registryCaCert.existingSecret .Values.registryCaCert.cert -}}
true
{{- end -}}
{{- end -}}

