{{/*
Validate credentials configuration.
An existing Secret or exactly one complete inline authentication mechanism must be provided.
*/}}
{{- define "qualys-scanner.validateCredentials" -}}
{{- if not .Values.qualysPlatformAuth.existingSecret }}
{{- $clientId := index .Values.scannerArgs "client-id" -}}
{{- $clientSecret := index .Values.scannerArgs "client-secret" -}}
{{- $accessToken := index .Values.scannerArgs "access-token" -}}
{{- if and (or $clientId $clientSecret) (not (and $clientId $clientSecret)) }}
{{- fail "Both scannerArgs.client-id and scannerArgs.client-secret must be provided for oauth authentication." -}}
{{- end }}
{{- if and $clientId $clientSecret $accessToken }}
{{- fail "Configure either scannerArgs.client-id and scannerArgs.client-secret, or scannerArgs.access-token, but not both authentication mechanisms." -}}
{{- end }}
{{- if not (or (and $clientId $clientSecret) $accessToken) }}
{{- fail "Either qualysPlatformAuth.existingSecret, both scannerArgs.client-id and scannerArgs.client-secret, or scannerArgs.access-token must be provided." -}}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Validate service TLS configuration.
When any serviceTls value is set, either existingSecret or both cert and key must be provided.
*/}}
{{- define "qualys-scanner.validateServiceTls" -}}
{{- if or .Values.serviceTls.existingSecret .Values.serviceTls.cert .Values.serviceTls.key }}
{{- if not .Values.serviceTls.existingSecret }}
{{- if or (not .Values.serviceTls.cert) (not .Values.serviceTls.key) }}
{{- fail "When serviceTls.cert or serviceTls.key is set, both serviceTls.cert and serviceTls.key must be provided." -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Validate Qualys Platform CA certificate configuration.
When any qualysPlatformCaCert value is set, either existingSecret or cert must be provided.
*/}}
{{- define "qualys-scanner.validateQualysPlatformCaCert" -}}
{{- if or .Values.qualysPlatformCaCert.existingSecret .Values.qualysPlatformCaCert.cert }}
{{- if not .Values.qualysPlatformCaCert.existingSecret }}
{{- if not .Values.qualysPlatformCaCert.cert }}
{{- fail "When qualysPlatformCaCert.cert is set, a non-empty cert value or qualysPlatformCaCert.existingSecret must be provided." -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Validate registry CA certificate configuration.
When any registryCaCert value is set, either existingSecret or cert must be provided.
*/}}
{{- define "qualys-scanner.validateRegistryCaCert" -}}
{{- if or .Values.registryCaCert.existingSecret .Values.registryCaCert.cert }}
{{- if not .Values.registryCaCert.existingSecret }}
{{- if not .Values.registryCaCert.cert }}
{{- fail "When registryCaCert.cert is set, a non-empty cert value or registryCaCert.existingSecret must be provided." -}}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}