# Qualys Harbor Adapter Service

[Qualys Harbor Adapter Service](https://www.qualys.com/) It is a pluggable scanner service for Harbor registry where we can scan images pushed to registry also have scans scheduled for all the images.

The installation will deploy the Qualys Harbor Adapter Service on each worker node as a statefulset. By default, it assumes `containerd` as the default runtimes on `Kubernetes cluster`.

## Prerequisites

### Kubernetes & Helm

- Kubernetes 1.17+
- Helm v3.x.x

### Get Repository Info

- helm repo add adapter-svc-helm-chart
- helm repo update

## Installing the Chart

Create a values file containing the required environment-specific configuration. Authentication must be supplied either through `qualysPlatformAuth.existingSecret` or through one supported inline authentication mechanism.

Install the chart:

```bash
helm install qualys-harbor-demo adapter-svc-helm-chart/qualys-harbor \
  --values values.yaml
```

The chart uses the QScanner image configured by `image`; no separate installation command is required for different container runtimes.

## Upgrading the Release

Use the following command to upgrade the chart:

`helm upgrade [RELEASE] [CHART] [flags]`

Where,

[RELEASE] is the release name.

[CHART] is the chart path.

e.g.

`helm upgrade qualys-harbor-demo adapter-svc-helm-chart/qualys-harbor`

## Uninstalling the Chart

Use the following command to uninstall the chart:

`helm uninstall RELEASE_NAME [...] [flags]`

e.g.

`helm uninstall qualys-harbor-demo`

## Persistent Cache requirement

With caching enabled we can increase scan job performance. [Note: first scan may take longer time but subsequent scans will be faster].
To support this we have enabled local as well as persistent cache.

cache-dir : location of cache mounted within pod.

local cache :- This cache will not be persisted incase of pods restart or redeployment. By default it is enabled and will be used as default location </opt/qualys/.cache/qualys/qscanner>. For other location can be set through cache-dir flag.

persistent cache :- This cache will be persisted accross redeployments or if pods restart. This will create persistent volume claim for all the replicas hence for this storage class should already be created with certain provisioning.
If storage class is manual then we need persistent volume created for every replica of scanner-pod.

```
Sample persistent volume yaml
{{- if .Values.persistence.enable }}
apiVersion: v1
kind: PersistentVolume
metadata:
  name: qscanner-cache0
  labels:
    type: local
spec:
  storageClassName: manual
  capacity:
    storage: {{ .Values.persistence.size }}
  accessModes: [ "ReadWriteMany" ]
  hostPath:
    path: {{ index .Values.scannerArgs "cache-dir" }}
{{- end }}
```
```
Sample storage class yaml
kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: manual
provisioner: kubernetes.io/no-provisioner
volumeBindingMode: WaitForFirstConsumer
```

## Configuration

### Configurable parameters

The following tables list the chart parameters and their defaults. Values containing credentials, private keys, or certificate data are intended only for development; use `existingSecret` references in production.

> **Restart behavior:** `/usr/share/qscanner/values.yaml` is mounted with `subPath`, so changes to ordinary configuration values require a pod restart. Projected Secret files are updated by Kubernetes, but whether QScanner reloads them without a restart depends on application behavior.

#### General and persistence

| Parameter | Description | Default |
| --- | --- | --- |
| `nameOverride` | Overrides the chart name used by generated resources. | `""` |
| `fullnameOverride` | Overrides the full workload and service name. Ensure the service TLS certificate contains this DNS name. | `"qualys-scanner"` |
| `helmInstallationPath` | Legacy installation-path setting; it is currently not consumed by any chart template. | `""` |
| `image` | QScanner container image. The `{version}` placeholder is replaced during chart packaging. | `"qualys/qscanner:{version}"` |
| `persistence.enable` | Enables a persistent cache volume. | `true` |
| `persistence.storageClass` | StorageClass used by the cache PVC. | `""` |
| `persistence.accessMode` | PVC access modes. | `["ReadWriteMany"]` |
| `persistence.size` | Requested cache volume size. | `3Gi` |

> **Important:** When persistence is enabled, set `scannerArgs.cache-dir` to a valid in-container path.

#### Redis and service

| Parameter | Description | Default |
| --- | --- | --- |
| `redis.url` | Redis connection URL used to store scan-job state. | `"redis://harbor-redis:6379/"` |
| `redis.maxActiveConnections` | Maximum number of active Redis connections. | `5` |
| `redis.maxIdleConnections` | Maximum number of idle Redis connections. | `5` |
| `service.replicaCount` | Number of scanner service replicas. | `1` |
| `service.logLevel` | Scanner service log level. | `"debug"` |
| `service.port` | Port on which the scanner service accepts requests. | `5000` |
| `service.workerThreads` | Number of workers processing scan jobs. | `2` |
| `service.scanJobTTLHour` | Retention period, in hours, for scan jobs and reports. | `1` |
| `service.maxTimeout` | Maximum duration for Redis and API network requests. | `1m` |

#### Qualys Platform authentication

| Parameter | Description | Default |
| --- | --- | --- |
| `qualysPlatformAuth.existingSecret` | Existing Secret containing either `client-id` and `client-secret`, or `access-token`. When set, no chart-managed authentication Secret is created. | `""` |
| `scannerArgs.client-id` | Inline OAuth client ID. Must be provided with `client-secret`; intended for development only. | `""` |
| `scannerArgs.client-secret` | Inline OAuth client secret. Must be provided with `client-id`; intended for development only. | `""` |
| `scannerArgs.access-token` | Inline JWT access token; intended for development only. Do not combine it with inline OAuth credentials. | `""` |

OAuth is inferred when both inline client credentials are set. Access-token authentication is inferred when only `scannerArgs.access-token` is set.

#### TLS and CA certificates

| Parameter | Description | Default |
| --- | --- | --- |
| `serviceTls.existingSecret` | Existing Secret containing the service TLS certificate and private key. Recommended for production. | `""` |
| `serviceTls.certKey` | Certificate key in an existing service TLS Secret. | `"tls.crt"` |
| `serviceTls.keyKey` | Private-key key in an existing service TLS Secret. | `"tls.key"` |
| `serviceTls.cert` | Inline service certificate as raw PEM; intended for development only. | `""` |
| `serviceTls.key` | Inline service private key as raw PEM; intended for development only. | `""` |
| `qualysPlatformCaCert.existingSecret` | Existing Secret containing the Qualys Platform CA certificate. | `""` |
| `qualysPlatformCaCert.certKey` | CA certificate key in the existing Qualys Platform Secret. | `"server-cert.crt"` |
| `qualysPlatformCaCert.cert` | Inline Qualys Platform CA certificate as raw PEM; intended for development only. | `""` |
| `registryCaCert.existingSecret` | Existing Secret containing the remote registry CA certificate. | `""` |
| `registryCaCert.certKey` | CA certificate key in the existing registry Secret. | `"registry-cert.crt"` |
| `registryCaCert.cert` | Inline registry CA certificate as raw PEM; intended for development only. | `""` |

#### Scanner arguments

| Parameter | Description | Default |
| --- | --- | --- |
| `scannerArgs.log-level` | Log level used for individual scan jobs. | `debug` |
| `scannerArgs.pod` | Qualys Platform identifier, such as `US1`, `EU1`, or `IN1`. | `""` |
| `scannerArgs.gateway-url` | Explicit Qualys Platform gateway URL; use when the platform is not represented by `pod`. | `""` |
| `scannerArgs.registry-skip-verify-tls` | Disables TLS verification for the remote registry. Use only for controlled testing. | `false` |
| `scannerArgs.skip-verify-tls` | Disables TLS verification for the Qualys Platform. Use only for controlled testing. | `false` |
| `scannerArgs.qualys-tags` | Comma-separated asset tags. A tag beginning with `qca_scan` enables continuous assessment. | `""` |
| `scannerArgs.proxy` | Proxy URL. When empty, QScanner may use proxy environment variables. | `""` |
| `scannerArgs.offline-scan` | Disables external API requests used to identify Java dependencies. | `false` |
| `scannerArgs.scan-timeout` | Maximum duration of a scan job. | `5m0s` |
| `scannerArgs.max-network-retries` | Maximum number of backend polling retries. | `10` |
| `scannerArgs.network-retry-wait-min` | Minimum wait between backend polling retries. | `5s` |
| `scannerArgs.cache` | Cache mode. | `"local"` |
| `scannerArgs.cache-dir` | QScanner cache directory. Must be set when persistence is enabled. | `""` |
| `scannerArgs.cache-cleanup-duration-threshold` | Age threshold after which cached entries become eligible for cleanup. | `4320h0m0s` |
| `scannerArgs.cache-cleanup-frequency` | Interval between cache-cleanup attempts. | `720h0m0s` |
| `scannerArgs.enable-cache-cleanup` | Enables cleanup of old cache entries. | `true` |

#### Resources and scheduling

| Parameter | Description | Default |
| --- | --- | --- |
| `resources.limits.cpu` | Container CPU limit. | `1000m` |
| `resources.limits.memory` | Container memory limit. | `2048Mi` |
| `resources.requests.cpu` | Container CPU request. | `800m` |
| `resources.requests.memory` | Container memory request. | `256Mi` |
| `tolerations` | Pod tolerations. | Not set |
| `nodeSelector` | Pod node selector. | Not set |
| `affinity` | Pod affinity and anti-affinity configuration. | Not set |

### Using an existing Kubernetes Secret for credentials

For production deployments it is recommended to create the Qualys Platform credentials Secret outside of Helm rather than passing them through `values.yaml`. The chart will then reference that Secret by name.

1. Create a Secret containing either the canonical OAuth keys (`client-id` and `client-secret`) or the canonical access-token key (`access-token`).

#### OAuth example:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: my-qualys-platform-credentials
type: Opaque
stringData:
  client-id: "<your-client-id>"
  client-secret: "<your-client-secret>"
```

#### Access-token example:

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: my-qualys-platform-token
type: Opaque
stringData:
  access-token: "<your-access-token>"
```

2. Install or upgrade the chart referencing either Secret:

```bash
helm install qualys-harbor-demo adapter-svc-helm-chart/qualys-harbor \
  --set qualysPlatformAuth.existingSecret=my-qualys-platform-credentials
```

When `qualysPlatformAuth.existingSecret` is set, the chart mounts its canonical credential files. For inline values, the chart infers OAuth from `client-id` plus `client-secret`, or access-token authentication from `access-token`. Inline OAuth credentials create `<release>-credentials`; an inline access token creates `<release>-access-token`.

The selected credentials are mounted under `/run/secrets/qualys/qscanner/`:

```text
# oauth
/run/secrets/qualys/qscanner/client-id
/run/secrets/qualys/qscanner/client-secret

# accessToken
/run/secrets/qualys/qscanner/access-token
```

---

### Using existing Kubernetes Secrets for TLS and CA certificates

For production deployments, store certificate material outside Helm and reference pre-created Kubernetes Secrets. This keeps certificates and private keys out of `values.yaml` and Helm release values.

> **Optional and independent:** Service TLS, the Qualys Platform CA, and the registry CA are independently optional. Configure only the certificate Secrets required by your deployment.

> **Development:** You can instead provide raw PEM through `serviceTls.cert`, `serviceTls.key`, `qualysPlatformCaCert.cert`, and `registryCaCert.cert`. The chart then creates release-scoped Secrets automatically.

#### 1. Service TLS certificate and private key

Create a standard `kubernetes.io/tls` Secret:

```bash
kubectl create secret tls my-qscanner-tls \
  --cert=path/to/tls.crt \
  --key=path/to/tls.key
```

The default source keys are **`tls.crt`** and **`tls.key`**. For an externally managed Secret with different key names, configure `serviceTls.certKey` and `serviceTls.keyKey`.

#### 2. Qualys Platform CA certificate

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: my-qualys-platform-ca
type: Opaque
stringData:
  server-cert.crt: |-
    -----BEGIN CERTIFICATE-----
    <qualys-platform-ca-certificate>
    -----END CERTIFICATE-----
```

If the Secret uses a different source key, set `qualysPlatformCaCert.certKey`.

#### 3. Remote registry CA certificate

```yaml
apiVersion: v1
kind: Secret
metadata:
  name: my-registry-ca
type: Opaque
stringData:
  registry-cert.crt: |-
    -----BEGIN CERTIFICATE-----
    <registry-ca-certificate>
    -----END CERTIFICATE-----
```

If the Secret uses a different source key, set `registryCaCert.certKey`.

#### 4. Reference the Secrets

Add the Secret names to your `values.yaml` file:

```yaml
serviceTls:
  existingSecret: my-qscanner-tls

qualysPlatformCaCert:
  existingSecret: my-qualys-platform-ca

registryCaCert:
  existingSecret: my-registry-ca
```

Then install or upgrade the chart with that file and the required authentication configuration:

```bash
helm upgrade --install qualys-harbor-demo adapter-svc-helm-chart/qualys-harbor \
  --values production-values.yaml
```

When `existingSecret` is configured, the chart references that Secret instead of creating the corresponding certificate Secret.

#### Generated Secret names

When raw PEM is provided inline for development, the chart creates these release-scoped Secrets:

| Purpose | Generated Secret name |
| --- | --- |
| Service TLS | `<release>-tls` |
| Qualys Platform CA | `<release>-qualys-platform-ca` |
| Registry CA | `<release>-registry-ca` |

#### Runtime certificate paths

All certificate files are projected under the common QScanner Secret directory:

| Purpose | Container path |
| --- | --- |
| Service certificate | `/run/secrets/qualys/qscanner/tls/tls.crt` |
| Service private key | `/run/secrets/qualys/qscanner/tls/tls.key` |
| Qualys Platform CA | `/run/secrets/qualys/qscanner/certs/qualys-platform-ca.crt` |
| Registry CA | `/run/secrets/qualys/qscanner/certs/registry-ca.crt` |


### Validation

The chart validates that required credentials and certificates are configured. `helm install` or `helm template` will fail with a clear error when:
- `qualysPlatformAuth.existingSecret` is not set and neither a complete OAuth credential pair nor an access token is provided inline.
- Only one of `scannerArgs.client-id` and `scannerArgs.client-secret` is provided.
- OAuth credentials and `scannerArgs.access-token` are both configured inline.
- Only one of `serviceTls.cert` and `serviceTls.key` is provided without `serviceTls.existingSecret`.

---
## Contact
Contact <support@qualys.com> for assistance.
