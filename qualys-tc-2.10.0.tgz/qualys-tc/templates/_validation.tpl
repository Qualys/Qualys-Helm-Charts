{{/*
Validate useCloudProviderRbac configuration
*/}}
{{- define "qualys-tc.validate.useCloudProviderRbac" -}}
{{- if .Values.global.clusterInfoArgs.useCloudProviderRbac }}
  {{- if ne .Values.global.clusterInfoArgs.cloudProvider "AZURE" }}
    {{- fail "useCloudProviderRbac is currently supported only for AZURE cloud provider. Please set global.clusterInfoArgs.cloudProvider to 'AZURE' or set global.clusterInfoArgs.useCloudProviderRbac to false" }}
  {{- end }}
  {{- if not .Values.azureWorkloadIdentity.clientId }}
    {{- fail "azureWorkloadIdentity.clientId is mandatory when useCloudProviderRbac is enabled. Please provide the Azure AD application (client) ID for Azure Workload Identity" }}
  {{- end }}
{{- end }}
{{- end }}
