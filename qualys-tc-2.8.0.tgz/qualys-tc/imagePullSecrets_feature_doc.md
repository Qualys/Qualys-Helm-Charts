# Feature: Enhanced Image Pull Secrets Configuration

## 1. Feature Introduction

We have introduced a new configuration parameter, `global.imagePullSecrets`, to replace the deprecated `global.imagePullSecret`. This enhancement provides greater flexibility and robustness for managing container image authentication in Kubernetes environments.

### Key Benefits:
*   **Multiple Registries Support**: You can now configure multiple secrets simultaneously. This is essential if your deployment pulls images from different private registries (e.g., one from AWS ECR and another from a private Docker Hub repository).
*   **Seamless Secret Rotation**: Support for a list of secrets allows for zero-downtime credential rotation. You can add a new secret to the list, deploy, and then remove the old secret in a subsequent update.
*   **Kubernetes Native**: The new structure aligns with the standard Kubernetes Pod specification for `imagePullSecrets`, making it intuitive for Kubernetes administrators.
*   **Flexible Secret Management**: You can choose to have the Helm chart create the secrets for you (using provided credentials) or reference existing secrets already present in your cluster.

## 2. Backward Compatibility

To ensure a smooth transition for existing deployments:
*   **`global.imagePullSecret` (Deprecated)**: The old string-based parameter is still supported. If defined, it will continue to work as before.
*   **Warning**: A warning message will be displayed during Helm installation or upgrade if the deprecated parameter is used, advising users to migrate to the new list-based format.
*   **Precedence**: If both `global.imagePullSecrets` (list) and `global.imagePullSecret` (string) are provided, the chart is designed to respect the new list format, though it is recommended to use only one to avoid confusion.

## 3. Configuration Examples

Below are examples of how to configure `global.imagePullSecrets` for various cloud providers and scenarios.

### 3.1 AWS Elastic Container Registry (ECR)

```yaml
global:
  imagePullSecrets:
    # Option 1: Create a new secret using a Docker config JSON (Recommended for ECR tokens)
    - name: aws-ecr-secret
      create: true
      # You can generate this using: aws ecr get-login-password ... | docker login ...
      # Then base64 encode your ~/.docker/config.json
      dockerconfigjson: "eyJhdXRocyI6eyI..." 
    
    # Option 2: Reference an existing secret created by an external process (e.g., an ECR helper)
    - name: existing-ecr-secret
      create: false
```

### 3.2 Azure Container Registry (ACR)

```yaml
global:
  imagePullSecrets:
    - name: azure-acr-secret
      create: true
      registry_url: "myregistry.azurecr.io"
      username: "00000000-0000-0000-0000-000000000000" # Service Principal ID
      password: "my-service-principal-password"
```

### 3.3 Google Container Registry (GCR) / Artifact Registry

```yaml
global:
  imagePullSecrets:
    - name: gcp-gcr-secret
      create: true
      registry_url: "gcr.io" # or region-docker.pkg.dev
      username: "_json_key"
      password: |
        {
          "type": "service_account",
          "project_id": "my-project",
          ...
        }
```

### 3.4 Oracle Cloud Infrastructure Registry (OCIR)

```yaml
global:
  imagePullSecrets:
    - name: oci-registry-secret
      create: true
      registry_url: "phx.ocir.io" # Region-specific URL
      username: "mytenancy/myusername"
      password: "my-auth-token"
```

### 3.5 Self-Managed Kubernetes / Private Registry

```yaml
global:
  imagePullSecrets:
    # Create a secret for a private corporate registry
    - name: private-registry-secret
      create: true
      registry_url: "registry.example.com"
      username: "myuser"
      password: "mypassword"
```

### 3.6 Migration Example (Backward Compatibility)

If you are currently using:

```yaml
global:
  imagePullSecret: "my-old-secret"
```

You should migrate to:

```yaml
global:
  imagePullSecrets:
    - name: "my-old-secret"
      create: false
```

## 4. Important Considerations

### 4.1 Secret Naming Convention
When you set `create: true`, the Helm chart creates the Kubernetes Secret using the exact name provided in the `name` field.

**Example:**
If you define:
```yaml
- name: my-ecr-secret
  create: true
```
The actual Kubernetes Secret created will be named: `my-ecr-secret`.

**Note:** Ensure that the secret name is unique within the namespace to avoid conflicts.

### 4.2 Precedence Rule
**Critical:** The chart logic prioritizes the deprecated `global.imagePullSecret` parameter for backward compatibility.
*   If `global.imagePullSecret` (string) is present and not empty, the new `global.imagePullSecrets` (list) **will be ignored**.
*   To use the new list feature, you **must** remove or comment out `global.imagePullSecret`.

## 5. Parameter Reference

| Parameter | Type | Required | Description |
| :--- | :--- | :--- | :--- |
| `name` | String | Yes | The name of the secret. |
| `create` | Boolean | Yes | `true` to create a new secret, `false` to use an existing one. |
| `registry_url` | String | No* | The registry server URL (e.g., `455812255056.dkr.ecr.us-west-2.amazonaws.com`). *Required if `create: true` and `dockerconfigjson` is not provided.* |
| `username` | String | No* | Registry username. *Required if `create: true` and `dockerconfigjson` is not provided.* |
| `password` | String | No* | Registry password or token. *Required if `create: true` and `dockerconfigjson` is not provided.* |
| `dockerconfigjson` | String | No | Base64 encoded content of `~/.docker/config.json`. Takes precedence over username/password if provided. |

## 6. Troubleshooting & Verification

1.  **Verify Secret Creation**:
    Check if the secret was created in your namespace:
    ```bash
    kubectl get secrets -n <your-namespace> | grep <your-secret-name>
    ```

2.  **Verify Pod Configuration**:
    Ensure the Pod is actually referencing the secret:
    ```bash
    kubectl get pod <pod-name> -n <your-namespace> -o jsonpath='{.spec.imagePullSecrets}'
    ```

3.  **Common Issues**:
    *   **ImagePullBackOff**: Often indicates the secret is missing, invalid, or the service account is not authorized to use it.
    *   **Secret Not Found**: Verify that the secret exists in the correct namespace with the expected name.

## 7. Security Best Practices

*   **Avoid Plain Text**: Do not commit plain-text passwords or tokens in your `values.yaml` files stored in version control.
*   **Use CI/CD Injection**: Inject sensitive credentials during the Helm install/upgrade process using `--set` arguments or environment variables.
    ```bash
    helm upgrade ... --set global.imagePullSecrets[0].password=$ECR_TOKEN
    ```
*   **Use dockerconfigjson**: For complex auth scenarios, generating the `dockerconfigjson` string and injecting it is often safer and less error-prone than handling raw username/passwords.
