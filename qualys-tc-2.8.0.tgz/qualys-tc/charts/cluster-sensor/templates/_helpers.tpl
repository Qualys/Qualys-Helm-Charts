{{/*
Create a unique name for a cluster-scoped resource.
*/}}
{{- define "qualys-tc.clusterResourceName" -}}
{{- printf "%s-%s-%s" .Release.Name .Release.Namespace .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return the appropriate imagePullSecrets
*/}}
{{- define "qualys-tc.imagePullSecrets" -}}
{{- $global := .Values.global | default dict }}
{{- $imagePullSecrets := .Values.imagePullSecrets | default $global.imagePullSecrets }}
{{- if $imagePullSecrets }}
imagePullSecrets:
  {{- range $imagePullSecrets }}
  - name: {{ .name }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Calculate GOMEMLIMIT as 75% of memory limit
Converts memory limit to MiB and returns 75% with MiB suffix
Supports units: Ki, Mi, Gi, K, M, G
Returns empty string if memory limit is not set
Fails if memory limit has unsupported unit
*/}}
{{- define "qualys-tc.goMemLimit" -}}
{{- if .Values.resources.limits.memory -}}
{{- $memoryLimit := .Values.resources.limits.memory -}}
{{- $memoryValue := $memoryLimit | regexFind "[0-9]+" | atoi -}}
{{- $memoryInMiB := 0 -}}
{{- if hasSuffix "Gi" $memoryLimit -}}
  {{- $memoryInMiB = mul $memoryValue 1024 -}}
{{- else if hasSuffix "Mi" $memoryLimit -}}
  {{- $memoryInMiB = $memoryValue -}}
{{- else if hasSuffix "Ki" $memoryLimit -}}
  {{- $memoryInMiB = div $memoryValue 1024 -}}
{{- else if hasSuffix "G" $memoryLimit -}}
  {{- $memoryInMiB = div (mul $memoryValue 1000000000) 1048576 -}}
{{- else if hasSuffix "M" $memoryLimit -}}
  {{- $memoryInMiB = div (mul $memoryValue 1000000) 1048576 -}}
{{- else if hasSuffix "K" $memoryLimit -}}
  {{- $memoryInMiB = div (mul $memoryValue 1000) 1048576 -}}
{{- else -}}
  {{- fail (printf "Unsupported memory unit in '%s'. Supported units: Ki, Mi, Gi, K, M, G" $memoryLimit) -}}
{{- end -}}
{{- $goMemLimit := mul (div $memoryInMiB 4) 3 -}}
{{- printf "%dMiB" $goMemLimit -}}
{{- end -}}
{{- end -}}
