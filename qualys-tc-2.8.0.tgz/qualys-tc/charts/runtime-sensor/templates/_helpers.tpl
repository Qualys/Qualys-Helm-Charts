{{/*
Create a unique name for a cluster-scoped resource.
*/}}
{{- define "qualys-tc.clusterResourceName" -}}
{{- printf "%s-%s-%s" .Release.Name .Release.Namespace .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Return the appropriate imagePullSecrets
*/}}
{{- define "qualys-tc.imagePullSecrets" -}}
{{- $global := .Values.global | default dict }}
{{- $imagePullSecrets := .Values.imagePullSecrets | default $global.imagePullSecrets }}
{{- if $imagePullSecrets }}
imagePullSecrets:
  {{- range $imagePullSecrets }}
  - name: {{ .name }}
  {{- end }}
{{- end }}
{{- end }}
