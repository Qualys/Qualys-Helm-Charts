{{/*
Create a unique name for a cluster-scoped resource.
*/}}
{{- define "qualys-tc.clusterResourceName" -}}
{{- printf "%s-%s-%s" .Release.Name .Release.Namespace .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
