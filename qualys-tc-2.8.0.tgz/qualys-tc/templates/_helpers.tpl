{{/*
Add Warning message for deprecating arguments
*/}}
{{- define "warning.message" -}}
{{- if and (.Values.qcsSensor).enabled (.Values.qcsSensor).containerd.enabled (.Values.qcsSensor).qualys.args.enableStorageDriver }}
WARNING: 'enableStorageDriver' flag will be deprecated in future releases.
{{- end }}
{{- if and (.Values.qcsSensor).enabled (.Values.qcsSensor).qualys.tolerations.enabled }}
WARNING: 'qcsSensor.qualys.tolerations' flag will be deprecated in future releases. Use 'qcsSensor.tolerations' instead.
{{- end }}
{{- if .Values.global.imagePullSecret }}
WARNING: 'global.imagePullSecret' parameter will be deprecated in future releases. Use 'global.imagePullSecrets' instead
{{- end }}
{{- end }}

{{/*
Create the .dockerconfigjson content
*/}}
{{- define "qualys-tc.dockerconfig" -}}
{{- if .dockerconfigjson }}
{{- .dockerconfigjson }}
{{- else }}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"auth\":\"%s\"}}}" .registry_url .username .password (printf "%s:%s" .username .password | b64enc) | b64enc }}
{{- end }}
{{- end }}

{{/*
Return the appropriate imagePullSecrets
*/}}
{{- define "qualys-tc.imagePullSecrets" -}}
{{- if .Values.global.imagePullSecret }}
imagePullSecrets:
  - name: {{ .Values.global.imagePullSecret }}
{{- else }}
{{- $imagePullSecrets := .Values.imagePullSecrets | default .Values.global.imagePullSecrets }}
{{- if $imagePullSecrets }}
imagePullSecrets:
  {{- range $imagePullSecrets }}
  - name: {{ .name }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}