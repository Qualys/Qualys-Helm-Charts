{{/*
Expand the name of the chart.
*/}}
{{- define "qcs-sensor.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "qcs-sensor.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "qcs-sensor.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "qcs-sensor.labels" -}}
helm.sh/chart: {{ include "qcs-sensor.chart" . }}
{{ include "qcs-sensor.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "qcs-sensor.selectorLabels" -}}
app.kubernetes.io/name: {{ include "qcs-sensor.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "qcs-sensor.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "qcs-sensor.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Add Warning message for deprecating arguments
*/}}
{{- define "warning.message" -}}
{{- if and .Values.containerd.enabled .Values.qualys.args.enableStorageDriver }}
WARNING: 'enableStorageDriver' flag will be deprecated in future releases.
{{- end }}
{{- if .Values.qualys.tolerations.enabled }}
WARNING: 'qualys.tolerations' will be deprecated in future releases. Use 'tolerations' instead.
{{- end }}
{{- if .Values.qualys.cpu }}
WARNING: 'qualys.cpu' will be deprecated in future releases. Use 'qualys.sensorContResources.limits.cpu' instead.
{{- end }}
{{- end }}

{{/*
Create a unique name for a cluster-scoped resource.
*/}}
{{- define "qualys-tc.clusterResourceName" -}}
{{- printf "%s-%s-%s" .Release.Name .Release.Namespace .name | trunc 63 | trimSuffix "-" -}}
{{- end -}}


{{/*
Return the appropriate imagePullSecrets
*/}}
{{- define "qualys-tc.imagePullSecrets" -}}
{{- $global := .Values.global | default dict }}
{{- $imagePullSecrets := .Values.imagePullSecrets | default $global.imagePullSecrets }}
{{- if $imagePullSecrets }}
imagePullSecrets:
  {{- range $imagePullSecrets }}
  - name: {{ .name }}
  {{- end }}
{{- end }}
{{- end }}

{{/*
Whether customer credentials should be sourced from a Kubernetes Secret.
Returns "true" when enabled (create=true or an existing name is set), empty otherwise.
*/}}
{{- define "qualys-tc.credentialsSecretEnabled" -}}
{{- $secret := (.Values.global | default dict).credentialsSecret | default dict -}}
{{- if or $secret.create $secret.name -}}
true
{{- end -}}
{{- end -}}

{{/*
Name of the Kubernetes Secret holding CUSTOMER_ID and ACTIVATION_ID.
When create=true, defaults to "qualys-credentials" unless an explicit name is provided.
When create=false, an explicit name is required.
*/}}
{{- define "qualys-tc.credentialsSecretName" -}}
{{- $secret := (.Values.global | default dict).credentialsSecret | default dict -}}
{{- if $secret.create -}}
{{- default "qualys-credentials" $secret.name -}}
{{- else -}}
{{- $secret.name | required ".Values.global.credentialsSecret.name is required when credentialsSecret.create is false." -}}
{{- end -}}
{{- end -}}

{{/*
Validate that a user-supplied credentials Secret exists in the cluster and
contains the required CUSTOMER_ID / ACTIVATION_ID keys.
Uses Helm lookup, so it only works during install/upgrade against a cluster.
*/}}
{{- define "qualys-tc.validate.credentialsSecret" -}}
{{- $global := .Values.global | default dict -}}
{{- $secret := $global.credentialsSecret | default dict -}}
{{- if and (not $secret.create) $secret.name -}}
  {{- $existingSecret := lookup "v1" "Secret" .Release.Namespace $secret.name -}}
  {{- if not $existingSecret -}}
    {{- fail (printf "invalid secret file for customer id: secret %s does not exist in namespace %s" $secret.name .Release.Namespace) -}}
  {{- end -}}
  {{- $customerId := index $existingSecret.data "CUSTOMER_ID" -}}
  {{- $activationId := index $existingSecret.data "ACTIVATION_ID" -}}
  {{- if not $customerId -}}
    {{- fail (printf "invalid secret file for customer id: secret %s is missing CUSTOMER_ID key" $secret.name) -}}
  {{- end -}}
  {{- if not $activationId -}}
    {{- fail (printf "invalid secret file for customer id: secret %s is missing ACTIVATION_ID key" $secret.name) -}}
  {{- end -}}
  {{- if eq $customerId "" -}}
    {{- fail (printf "invalid secret file for customer id: secret %s has empty CUSTOMER_ID key" $secret.name) -}}
  {{- end -}}
  {{- if eq $activationId "" -}}
    {{- fail (printf "invalid secret file for customer id: secret %s has empty ACTIVATION_ID key" $secret.name) -}}
  {{- end -}}
{{- end -}}
{{- end -}}

{{/*
Env entries that source CUSTOMER_ID and ACTIVATION_ID from the credentials Secret.
Callers must guard with "qualys-tc.credentialsSecretEnabled".
*/}}
{{- define "qualys-tc.credentialsSecretEnv" -}}
- name: CUSTOMER_ID
  valueFrom:
    secretKeyRef:
      name: {{ include "qualys-tc.credentialsSecretName" . }}
      key: CUSTOMER_ID
- name: ACTIVATION_ID
  valueFrom:
    secretKeyRef:
      name: {{ include "qualys-tc.credentialsSecretName" . }}
      key: ACTIVATION_ID
{{- end -}}